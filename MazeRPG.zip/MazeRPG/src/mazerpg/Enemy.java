/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package mazerpg;

/**
 *
 * @author Tre'on Russell
 */
public class Enemy
{

    private int health;
    private int damage;
    private int minDamage;
    private int maxDamage;

    public Enemy(int health, int floor)
    {
        this.health = health;
        // Scale damage with floor
        this.minDamage = floor * 2;  // Minimum damage increases per floor
        this.maxDamage = floor * 5;  // Maximum damage increases more
    }

    public int getHealth()
    {
        return health;
    }

    public void takeDamage(int amount)
    {
        health -= amount;
    }

    public int attack()
    {
        return (int) (Math.random() * (maxDamage - minDamage + 1)) + minDamage;
    }
}
