/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package mazerpg;

/**
 *
 * @author Tre'on Russell
 */
public class Boss extends Enemy
{

    private final String rewardItem;
    private final int rewardXP;

    public Boss(int floor)
    {
        super(50 + floor * 20, 10 + floor * 5); // High health and damage scaling with floor
        this.rewardItem = determineReward();
        this.rewardXP = 50 + floor * 20; // Significant XP reward
    }

    private String determineReward()
    {
        // Strong items for defeating the boss
        String[] possibleRewards = {"Golden Stick", "Emeraled Pendant", "Leather Jacket"};
        return possibleRewards[(int) (Math.random() * possibleRewards.length)];
    }

    public String getRewardItem()
    {
        return rewardItem;
    }

    public int getRewardXP()
    {
        return rewardXP;
    }

    @Override
    public int attack()
    {
        // Boss deals more random damage within a wider range
        int minDamage = super.attack() + 5;
        int maxDamage = minDamage + 10;
        return (int) (Math.random() * (maxDamage - minDamage + 1)) + minDamage;
    }
}
