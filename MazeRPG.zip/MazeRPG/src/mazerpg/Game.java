/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package mazerpg;

/**
 *
 * @author Tre'on Russell
 */
import java.util.Scanner;

public class Game
{

    private Map map;
    private Player player;
    private int floor = 1;

    public void start()
    {
        System.out.println("You wake up to a thunderstorm outside."
                + "\nyou're inside of an abandoned office building. "
                + "\nYou look around, no one is there, and the windows are "
                + "\ncovered in fog. You hear something shift near you approach "
                + "\nand the mannequin jumps out and tries to attack you."
                + "\nYou quickly dodge the attack and run down the first "
                + "\nflight of stairs you see after which you then duck and "
                + "\ndive into a corner.  You lie and wait, wondering if you've"
                + "\ngone crazy until you hear something else shifting down the"
                + "\nhallway…");
        System.out.println("Would you like to:");
        System.out.println("1. Create a custom character");
        System.out.println("2. Select a predefined class");
        Scanner scanner = new Scanner(System.in);

        int choice = scanner.nextInt();
        if (choice == 1) {
            player = createCustomCharacter(scanner);
        }
        else if (choice == 2) {
            player = chooseClass(scanner);
        }
        else {
            System.out.println("Invalid choice! Defaulting to Warrior class.");
            player = new Player(30, 5, 0, 3, 2); // Warrior default
        }

        System.out.println("Its time to check that noise out...");
        player.displayStatus();

        map = new Map(floor);
        playGame();
    }

    private Player createCustomCharacter(Scanner scanner)
    {
        int skillPoints = 10;
        int health = 20, mp = 0, speed = 0, accuracy = 0;

        System.out.println("You have 10 skill points to distribute among the following attributes:");
        while (skillPoints > 0) {
            System.out.println("Skill points remaining: " + skillPoints);
            System.out.println("1. Health (Current: " + health + ")");
            System.out.println("2. MP (Current: " + mp + ")");
            System.out.println("3. Speed (Current: " + speed + ")");
            System.out.println("4. Accuracy (Current: " + accuracy + ")");
            System.out.println("Allocate points to (1-4): ");
            int allocation = scanner.nextInt();

            System.out.println("How many points to allocate?");
            int points = scanner.nextInt();
            if (points > 0 && points <= skillPoints) {
                switch (allocation) {
                    case 1 ->
                        health += points;
                    case 2 ->
                        mp += points;
                    case 3 ->
                        speed += points;
                    case 4 ->
                        accuracy += points;
                    default ->
                        System.out.println("Invalid choice!");
                }
                skillPoints -= points;
            }
            else {
                System.out.println("CAN'T DO THAT");
            }
        }

        System.out.println("Custom character created!");
        return new Player(health, 5, mp, speed, accuracy);
    }

    private Player chooseClass(Scanner scanner)
    {
        System.out.println("Choose a class:");
        System.out.println("1. Warrior (High Health and Strength)");
        System.out.println("2. Thief (High Speed)");
        System.out.println("3. Archer (High Accuracy)");
        System.out.println("4. Mage (High MP)");
        int choice = scanner.nextInt();

        return switch (choice) {
            case 1 ->
                new Player(30, 7, 0, 3, 2); // Warrior
            case 2 ->
                new Player(20, 5, 0, 7, 3); // Thief
            case 3 ->
                new Player(20, 5, 0, 3, 7); // Archer
            case 4 ->
                new Player(15, 4, 10, 2, 3); // Mage
            default -> {
                System.out.println("Invalid choice! Defaulting to Warrior.");
                yield new Player(30, 7, 0, 3, 2);
            }
        };
    }

    private void playGame()
    {
        Scanner scanner = new Scanner(System.in);

        while (true) {
            map.display(player.getX(), player.getY(), floor);
            System.out.println("Options: W (up), A (left), S (down), D (right), I (Inventory/Status)");
            System.out.println("Rolling the dice to determine your maximum movement...");

            int maxSteps = player.rollDice();
            System.out.println("You rolled a " + maxSteps + "!");

            System.out.println("Choose how many spaces to move (1-" + maxSteps + "): ");
            int steps = scanner.nextInt();
            while (steps < 1 || steps > maxSteps) {
                System.out.println("Invalid number of spaces! Choose a number between 1 and " + maxSteps + ": ");
                steps = scanner.nextInt();
            }

            System.out.println("Choose a direction to walk in: W (up), A (left), S (down), D (right)");
            char choice = scanner.next().toUpperCase().charAt(0);

            boolean validMove = player.move(steps, choice, map);
            if (!validMove) {
                System.out.println("Try another direction!");
                continue;
            }

            char tile = map.getTile(player.getX(), player.getY());
            switch (tile) {
                case 'E' -> {
                    System.out.println("An enemy is approaching!");
                    Enemy enemy = new Enemy(20 + floor * 10, floor);
                    new Battle(player, enemy).start();
                    map.clearTile(player.getX(), player.getY());
                }
                case 'T' -> {
                    System.out.println("You found something useful!");
                    map.clearTile(player.getX(), player.getY());
                    player.findTreasure();
                }
                case 'S' -> {
                    if (floor < 3) {
                        System.out.println("You found a stairwell! What lies beyond...?");
                        floor++;
                        map = new Map(floor);
                        player.resetPosition();
                    }
                    else {
                        System.out.println("You found the stairwell, but SOMETHING IS BLOCKING IT!");
                    }
                }
            }

            if (map.isTrap(player.getX(), player.getY())) {
                System.out.println("You triggered a trap! You take 10 damage.");
                player.adjustHealth(-10);
                map.revealTrap(player.getX(), player.getY());
            }

            if (map.isBoss(player.getX(), player.getY())) {
                System.out.println("You encountered the final boss! Prepare for an epic battle!");
                Boss boss = new Boss(floor);
                new Battle(player, boss).start();
                map.clearBoss(player.getX(), player.getY());
                System.out.println("You defeated the final boss! Congratulations, you have completed the game!");
                return; // End the game
            }
        }
    }

}
