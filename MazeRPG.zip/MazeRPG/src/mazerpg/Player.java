/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package mazerpg;

/**
 *
 * @author Tre'on Russell
 */
import java.util.*;
import mazerpg.Map;

public class Player
{

    private int health;
    private int strength;
    private int x = 0, y = 0;
    private final ArrayList<String> inventory = new ArrayList<>();
    private final Random random = new Random();
    private int level = 1;
    private int experience = 0;
    private static int experienceThreshold = 10;
    private int maxHealth;
    private int luck;
    private int mp;
    private int maxMP;
    private int speed;
    private int accuracy;
    private final List<String> abilities = new ArrayList<>();

    public Player(int health, int strength, int mp, int speed, int accuracy)
    {
        this.health = health;
        this.maxHealth = health;
        this.strength = strength;
        this.mp = mp;
        this.maxMP = mp;
        this.speed = speed;
        this.accuracy = accuracy;
        this.level = 1;
        this.experience = 0;
        this.experienceThreshold = 10;

        if (mp > 0) { // If the player has significant MP, they start as a Mage
            unlockAbility(1); // Mages start with "Fireball"
        }
    }

    public int getX()
    {
        return x;
    }

    public int getY()
    {
        return y;
    }

    public void resetPosition()
    {
        x = 0;
        y = 0;
    }

    public boolean move(int steps, char direction, Map map)
    {
        int newX = x, newY = y;

        switch (direction) {
            case 'W' ->
                newX -= steps; // Move up
            case 'S' ->
                newX += steps; // Move down
            case 'A' ->
                newY -= steps; // Move left
            case 'D' ->
                newY += steps; // Move right
            default -> {
                System.out.println("Invalid direction!");
                return false;
            }
        }

        // Check if the destination is valid
        if (map.isValidPosition(newX, newY)) {
            x = newX;
            y = newY;
            return true;
        }
        else {
            System.out.println("You can't move that far in that direction!");
            return false;
        }
    }

    public int rollDice()
    {
        return (int) (Math.random() * 6) + 1; // Generates a number between 1 and 6
    }

    public void findTreasure()
    {
        if (random.nextDouble() < 0.5) {
            inventory.add("Health Potion");
            System.out.println("You found a Health Potion!");
        }
        else {
            inventory.add("Strength Elixir");
            System.out.println("You found a Strength Elixir!");
        }
    }

    public int getHealth()
    {
        return health;
    }

    public void adjustHealth(int amount)
    {
        health += amount;
        if (health > maxHealth) {
            health = maxHealth; // Cap health at maxHealth
        }
        System.out.println("Health adjusted by: " + amount);
        System.out.println("Current health: " + health + "/" + maxHealth);
    }

    public int getStrength()
    {
        return strength;
    }

    public void increaseStrength(int amount)
    {
        strength += amount;
        System.out.println("Strength increased by: " + amount);
    }

    public ArrayList<String> getInventory()
    {
        return inventory;
    }

    public void displayStatus()
    {
        int xpUntilNextLevel = experienceThreshold - experience;
        System.out.println("Player Status:");
        System.out.println("Level: " + level);
        System.out.println("Experience: " + experience + "/" + experienceThreshold);
        System.out.println("XP until next level: " + xpUntilNextLevel);
        System.out.println("Health: " + health + "/" + maxHealth);
        System.out.println("Strength: " + strength);
        System.out.println("Luck: " + luck);
        System.out.println("Inventory: " + (inventory.isEmpty() ? "Empty" : String.join(", ", inventory)));
        System.out.println("MP: " + mp + "/" + maxMP);
        System.out.println("Speed: " + speed);
        System.out.println("Accuracy: " + accuracy);
    }

    public void useItem()
    {
        if (inventory.isEmpty()) {
            System.out.println("Your inventory is empty!");
            return;
        }

        System.out.println("Inventory:");
        for (int i = 0; i < inventory.size(); i++) {
            System.out.println((i + 1) + ". " + inventory.get(i));
        }

        System.out.println("Choose an item to use (enter the number): ");
        Scanner scanner = new Scanner(System.in);
        int choice = scanner.nextInt();

        if (choice < 1 || choice > inventory.size()) {
            System.out.println("Invalid choice!");
            return;
        }

        String item = inventory.remove(choice - 1);
        switch (item) {
            case "Health Potion" -> {
                if (health < maxHealth) {
                    adjustHealth(15);
                    System.out.println("You used a Health Potion!");
                }
                else {
                    System.out.println("Your health is already full!");
                }
            }
            case "Strength Elixir" -> {
                increaseStrength(3);
                System.out.println("You used a Strength Elixir!");
            }
            default ->
                System.out.println("This item has no effect!");
        }
    }

    public int getLevel()
    {
        return level;
    }

    public int getExperience()
    {
        return experience;
    }

    public void gainExperience(int amount)
    {
        experience += amount;
        System.out.println("You gained " + amount + " experience points!");

        while (experience >= experienceThreshold) { // Allow multiple level-ups if needed
            levelUp();
        }
    }

    private void levelUp()
    {
        level++;
        experience -= experienceThreshold;
        experienceThreshold += level * 5;
        maxHealth += 10;
        health = Math.min(health, maxHealth);
        strength += 2;

        if (level <= 5) {
            unlockAbility(level);
        }

        System.out.println("Seems like you got stronger... Level Increased to" + level + "!");
        System.out.println("Max health increased to " + maxHealth + ".");
        System.out.println("Strength increased to " + strength + ".");
        System.out.println("Next level requires " + experienceThreshold + " XP.");
    }

    private void unlockAbility(int level)
    {
        switch (level) {
            case 2 ->
                System.out.println("New Ability Unlocked: Fireball (Cost: 5 MP, Deals 15 Damage)");
            case 3 ->
                System.out.println("New Ability Unlocked: Quick Heal (Cost: 5 MP, Restores 10 Health)");
            case 4 ->
                System.out.println("New Ability Unlocked: Rapid Strike (No MP, High Accuracy)");
            case 5 ->
                System.out.println("New Ability Unlocked: Ultimate Blast (Cost: 10 MP, Deals 30 Damage)");
        }
    }

    public int getLuck()
    {
        return luck;
    }

    public void increaseLuck(int amount)
    {
        luck += amount;
        System.out.println("Luck increased by: " + amount);
    }

    public int getMP()
    {
        return mp;
    }

    public void adjustMP(int amount)
    {
        mp += amount;
        if (mp > maxMP) {
            mp = maxMP;
        }
        if (mp < 0) {
            mp = 0;
        }
        System.out.println("MP increased by " + amount + ". Current MP: " + mp
                + "/" + maxMP);
    }

    public int getSpeed()
    {
        return speed;
    }

    public int getAccuracy()
    {
        return accuracy;
    }

    public void useAbility(Enemy enemy)
    {
        if (abilities.isEmpty()) {
            System.out.println("You have no abilities!");
            return;
        }

        System.out.println("Available abilities:");
        for (int i = 0; i < abilities.size(); i++) {
            System.out.println((i + 1) + ". " + abilities.get(i));
        }

        Scanner scanner = new Scanner(System.in);
        System.out.println("Choose an ability to use: ");
        int choice = scanner.nextInt();

        if (choice < 1 || choice > abilities.size()) {
            System.out.println("Invalid choice!");
            return;
        }

        String ability = abilities.get(choice - 1);
        switch (ability) {
            case "Fireball (Cost: 5 MP, Deals 15 Damage)" -> {
                if (mp >= 5) {
                    adjustMP(-5);
                    enemy.takeDamage(15);
                    System.out.println("You cast Fireball, dealing 15 damage!");
                }
                else {
                    System.out.println("Not enough MP!");
                }
            }
            case "Heal (Cost: 5 MP, Restores 10 Health)" -> {

                if (mp >= 5) {
                    adjustMP(-5);
                    adjustHealth(10);
                    System.out.println("You cast Heal, restoring 10 health!");
                }
                else {
                    System.out.println("Not enough MP!");
                }
            }
            case "Smash Strike (No MP, High Accuracy)" -> {
                int hitChance = (int) (Math.random() * 100) + 1;
                if (hitChance <= accuracy + 20) {
                    int damage = (int) (Math.random() * strength) + 1;
                    enemy.takeDamage(damage);
                    System.out.println("You used Smash Strike, dealing " + damage + " damage!");
                }
                else {
                    System.out.println("Rapid Strike missed!");
                }
            }
            case "Final Blast (Cost: 10 MP, Deals 30 Damage)" -> {
                if (mp >= 10) {
                    adjustMP(-10);
                    enemy.takeDamage(30);
                    System.out.println("You cast Final Blast, dealing 30 damage!");
                }
                else {
                    System.out.println("Not enough MP!");
                }
            }
        }
    }
}
