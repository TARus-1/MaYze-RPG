/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package mazerpg;

/**
 *
 * @author Tre'on Russell
 */
import java.util.Scanner;

public class Battle
{

    private final Player player;
    private final Enemy enemy;

    public Battle(Player player, Enemy enemy)
    {
        this.player = player;
        this.enemy = enemy;
    }

    public void start()
    {
        Scanner scanner = new Scanner(System.in);

        while (player.getHealth() > 0 && enemy.getHealth() > 0) {
            System.out.println("Choose an action: 1. Attack  2. Flee  3. Inventory/Status  4. Use Ability");
            int choice = scanner.nextInt();

            if (choice == 1) {
                int hitChance = (int) (Math.random() * 100) + 1;
                if (hitChance <= player.getAccuracy()) {
                    int damage = (int) (Math.random() * player.getStrength()) + 1;
                    enemy.takeDamage(damage);
                    System.out.println("You hit the enemy for " + damage + " damage!");
                }
                else {
                    System.out.println("You missed!");
                }
            }
            else if (choice == 2) {
                if (attemptFlee()) {
                    System.out.println("You successfully fled the battle!");
                    return;
                }
                else {
                    System.out.println("Couldn't Escape!! The enemy attacks!");
                }
            }
            else if (choice == 3) {
                player.displayStatus();
                System.out.println("Would you like to use an item? (Y/N)");
                char useItemChoice = scanner.next().toUpperCase().charAt(0);
                if (useItemChoice == 'Y') {
                    player.useItem();
                }
            }
            else if (choice == 4) {
                player.useAbility(enemy);
            }
            else {
                System.out.println("Invalid action!");
            }

            if (enemy.getHealth() > 0) {
                int enemyDamage = enemy.attack();
                player.adjustHealth(-enemyDamage);
                System.out.println("The enemy dealt " + enemyDamage + " damage!");
            }
        }

        if (player.getHealth() <= 0) {
            System.out.println("You were defeated! Game over.");
            System.exit(0);
        }
        else {
            System.out.println("You defeated the enemy!");
        }
    }

    private boolean attemptFlee()
    {
        int fleeChance = 50 + player.getLuck() * 5; // Base chance + luck modifier
        int roll = (int) (Math.random() * 100) + 1;
        return roll <= fleeChance;
    }

}
