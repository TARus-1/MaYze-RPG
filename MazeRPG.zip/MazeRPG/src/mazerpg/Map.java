/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package mazerpg;

/**
 *
 * @author Tre'on Russell
 */
import java.util.Random;

public class Map
{

    private static final int size = 10;
    private final char[][] grid = new char[size][size];
    private final Random random = new Random();
    private static final char trap = 'H'; //hazard (invisible until triggered)
    private static final char BOSS = 'B'; // hidden boss

    public Map(int floor)
    {
        generate(floor);
    }

    private void generate(int floor)
    {
        for (int i = 0; i < size; i++) {
            for (int j = 0; j < size; j++) {
                double rand = random.nextDouble();
                if (rand < 0.1) {
                    grid[i][j] = 'E'; // Enemy
                }
                else if (rand < 0.15) {
                    grid[i][j] = 'T'; // Treasure
                }
                else if (rand < 0.2) {
                    grid[i][j] = 'W'; // Wall
                }
                else if (rand < 0.25) {
                    grid[i][j] = 'H'; // Trap
                }
                else {
                    grid[i][j] = '.'; // empty space
                }
            }
        }
        placeStairwell();
        placeBoss(floor); //add boss
    }

    public boolean isTrap(int x, int y)
    {
        return grid[x][y] == trap;
    }

    public void revealTrap(int x, int y)
    {
        grid[x][y] = '.'; // Remove the trap after triggering
    }

    private void placeStairwell()
    {
        int stairX, stairY;
        do {
            stairX = random.nextInt(size);
            stairY = random.nextInt(size);
        }
        while (grid[stairX][stairY] != '.');
        grid[stairX][stairY] = 'S';
    }

    public char getTile(int x, int y)
    {
        return grid[x][y];
    }

    public void clearTile(int x, int y)
    {
        grid[x][y] = '.';
    }

    public boolean isWall(int x, int y)
    {
        return grid[x][y] == 'W';
    }

    public boolean isValidPosition(int x, int y)
    {
        return x >= 0 && x < size && y >= 0 && y < size && !isWall(x, y);
    }

    public void display(int playerX, int playerY, int floor)
    {
        System.out.println("Floor: " + floor);
        for (int i = 0; i < size; i++) {
            for (int j = 0; j < size; j++) {
                if (i == playerX && j == playerY) {
                    System.out.print("P ");
                }
                else {
                    System.out.print(grid[i][j] + " ");
                }
            }
            System.out.println();
        }
    }

    private void placeBoss(int floor)
    {
        if (floor == 3) { // Only place the final boss on the third floor
            int bossX, bossY;
            do {
                bossX = random.nextInt(size);
                bossY = random.nextInt(size);
            }
            while (grid[bossX][bossY] != '.'); // place boss only on empty spaces
            grid[bossX][bossY] = BOSS;
        }
    }

    public boolean isBoss(int x, int y)
    {
        return grid[x][y] == BOSS;
    }

    public void clearBoss(int x, int y)
    {
        grid[x][y] = '.'; // Remove the boss after the fight
    }
}
